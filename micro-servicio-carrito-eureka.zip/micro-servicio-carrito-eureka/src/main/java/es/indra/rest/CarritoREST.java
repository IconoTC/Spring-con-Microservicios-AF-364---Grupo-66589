package es.indra.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import es.indra.business.ICarritoBS;
import es.indra.models.Carrito;

@RestController
public class CarritoREST {
	
	@Autowired
	private ICarritoBS bs;
	
	// http://localhost:8003/crear/Pepito
	@PostMapping("/crear/{usuario}")
	public Carrito crear(@PathVariable String usuario) {
		return  bs.crear(usuario);
	}
    
	// http://localhost:8003/agregar/id/4/cantidad/50/usuario/Pepito
	@PutMapping("/agregar/id/{id}/cantidad/{cantidad}/usuario/{usuario}")
	public Carrito agregarPedido(@PathVariable Long id, @PathVariable Integer cantidad, @PathVariable String usuario) {
		return bs.agregarPedido(id, cantidad, usuario);
	}
    
	// http://localhost:8003/consultar/Pepito
	@GetMapping("/consultar/{usuario}")
	public Carrito consultar(@PathVariable String usuario) {
		return bs.consultar(usuario);
	}
    
	// http://localhost:8003/id/4/usuario/Pepito
	@DeleteMapping("/eliminar/id/{id}/usuario/{usuario}")
	public Carrito eliminarPedido(@PathVariable Long id, @PathVariable String usuario) {
		return bs.eliminarPedido(id, usuario);
	}

}
