package es.indra.business;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import es.indra.models.Producto;
import es.indra.persistence.ProductosDAO;

@Service
public class ProductosBSImpl implements IProductosBS{
	
	@Autowired
	private ProductosDAO dao;  // Inyeccion de dependencia   DI

	@Override
	public List<Producto> consultarTodos() {
		return dao.findAll();
	}

	@Override
	public Producto buscarProducto(Long id) {
		return dao.findById(id).orElse(new Producto());
	}

}
