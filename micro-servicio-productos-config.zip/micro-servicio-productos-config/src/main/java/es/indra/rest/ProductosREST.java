package es.indra.rest;

import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import es.indra.business.IProductosBS;
import es.indra.models.Producto;

@RefreshScope
@RestController
public class ProductosREST {
	
	// Inyectamos el valor de la propiedad recogida del servidor de configuracion
	@Value("${configuracion.modo}")
	private String texto;
	
	// Con puerto dinamico no funciona entonces inyectamos la peticion
	//@Value("${server.port}")
	//private Integer port;
	
	@Autowired
	private HttpServletRequest request;
	
	@Autowired
	private IProductosBS bs;
	
	// http://localhost:8001/listar
	@GetMapping("/listar")
	public List<Producto> listar(){
		// 1ª opcion
//		List<Producto> lista = bs.consultarTodos();
//		for (Producto producto : lista) {
//			producto.setPort(port);
//		}
//		return lista;
		
		// 2º opcion -> A partir de Java 8 podemos utilizar los streams
		return bs.consultarTodos()
				.stream()
				.map(prod -> {
					//prod.setPort(port);
					prod.setPort(request.getLocalPort());
					return prod;
				})
				.collect(Collectors.toList());
	}
	
	// http://localhost:8001/buscar/2
	@GetMapping("/buscar/{id}")
	public Producto buscar(@PathVariable(name = "id") Long id) throws InterruptedException {
		
		// Mostramos el modo de configuracion
		System.out.println("******************* " + texto);
		
		Producto producto = bs.buscarProducto(id);
		
		// Si no ha encontrado el producto, la instancia recibida esta vacia
		// entonces lanzaremos una excepcion
		if (producto.getDescripcion() == null) {
			throw new RuntimeException("Error al buscar el producto");
		}
		
		// Probar peticiones lentas que superen 2 segundos
		if (id == 1L) {
			//Thread.sleep(5_000);
		}

		
		
		//producto.setPort(port);
		producto.setPort(request.getLocalPort());
		return producto;
	}

}
